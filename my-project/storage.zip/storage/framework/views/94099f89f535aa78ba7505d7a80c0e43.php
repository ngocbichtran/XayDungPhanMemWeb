<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Admin'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <script src="https://cdn.tailwindcss.com?plugins=forms"></script>

    
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700&display=swap" rel="stylesheet">

    
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">

    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    
    <link rel="stylesheet"
      href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>

    
    <link rel="stylesheet"
        href="https://cdn.datatables.net/1.13.8/css/dataTables.tailwindcss.min.css">
    <script src="https://cdn.datatables.net/1.13.8/js/dataTables.tailwindcss.min.js"></script>

    <style>
      

    </style>

    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="bg-gray-100">
<div class="flex min-h-screen">

    
    <aside class="w-64 bg-white border-r p-4">
        <h2 class="font-bold text-blue-600 mb-4">Shop Admin</h2>

        <nav class="space-y-1">
            <a href="<?php echo e(route('products.index')); ?>"
               class="block px-3 py-2 rounded
               <?php echo e(request()->routeIs('products.*') ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'); ?>">
                Products
            </a>

            <a href="<?php echo e(route('categories.index')); ?>"
               class="block px-3 py-2 rounded
               <?php echo e(request()->routeIs('categories.*') ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'); ?>">
                Categories
            </a>
            <a href="<?php echo e(route('pages.index')); ?>"
               class="block px-3 py-2 rounded
               <?php echo e(request()->routeIs('pages.*') ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'); ?>">
                Pages
            </a>
        </nav>
    </aside>

    
    <main class="flex-1 p-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

</div>

<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH D:\XayDungPhanMemWeb\my-project\resources\views/layout/admin.blade.php ENDPATH**/ ?>