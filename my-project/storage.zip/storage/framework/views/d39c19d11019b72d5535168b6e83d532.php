<?php $__env->startSection('title', 'Quản lý sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-bold">Danh sách loại sản phẩm</h1>

    <a href="<?php echo e(route('categories.create')); ?>"
       class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        + Thêm loại sản phẩm
    </a>
</div>

<div class="bg-white p-4 rounded shadow">
    <table id="categories" class="w-full text-sm border">
        <thead>
            <tr class="bg-gray-50">
                <th>ID</th>
                <th>Tên</th>
                <th>Mô tả</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b">
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->description); ?></td>
                    <td>
                        <?php if($category->status == 1): ?>
                            <span class="text-green-600">Hoạt động</span>
                        <?php else: ?>
                            <span class="text-red-600">Ẩn</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="text-blue-600">Sửa</a> |
                        <form action="<?php echo e(route('categories.destroy', $category->id)); ?>"
                              method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600"
                                onclick="return confirm('Xóa loại sản phẩm này?')">
                                Xóa
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XayDungPhanMemWeb\my-project\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>